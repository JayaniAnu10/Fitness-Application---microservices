import Button from "@mui/material/Button";
import {
  BrowserRouter as Router,
  Navigate,
  Route,
  Routes,
  useLocation,
} from "react-router";
function App() {
  return (
    <>
      <Router>
        <Button variant="contained" color="secondary">
          Login
        </Button>
      </Router>
    </>
  );
}

export default App;
