import ReactDOM from "react-dom/client";

import { Provider } from "react-redux";
import store from "./store/store";

import App from "./App";

// As of React 18
const container = document.getElementById("root");

if (!container) {
  throw new Error("Root container with id 'root' not found");
}

const root = ReactDOM.createRoot(container);
root.render(
  <Provider store={store}>
    <App />
  </Provider>,
);
